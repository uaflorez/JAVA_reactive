package com.bancolombia.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsuserApplicationTests {

	@Test
	void contextLoads() {
	}

}
