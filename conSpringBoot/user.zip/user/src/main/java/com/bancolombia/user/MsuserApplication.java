package com.bancolombia.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsuserApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsuserApplication.class, args);
	}

}
